<?php
if (isset($_GET['p']) && isset($_GET['q'])){
	
	if ($_GET['q']="editar") {
		$orden=$_GET['p'];
}
		require("conexion.php");
		$con=conectar();
		$sql="SELECT orden,dni,nombreApellido,escuela,departamento,cargo,jurado,grupo,oralTP,apelOralTP,apelRes,residencia FROM directivos WHERE orden='$orden'";       
		$stmt= $con-> prepare($sql);
		$result = $stmt->execute();
		$rows= $stmt->fetchAll(\PDO::FETCH_OBJ);

		foreach ($rows as $row ) { 
			$orden=$row->orden;
			$dni=$row->dni;
			$nombreApellido=$row->nombreApellido;
			$escuela= $row->escuela;
			$departamento=$row->departamento;
			$cargo=$row->cargo;
			$jurado=$row->jurado;
			$grupo=$row->grupo;
			$oralTP=$row->oralTP;
			$apelOralTP=$row->apelOralTP;
			$apelRes=$row->apelRes;
			$residencia=$row->residencia;
		}
		$qp="SELECT grupo FROM directivos WHERE grupo ='$grupo'; ";
		$stmt= $con-> prepare($qp);
	    $result = $stmt->execute();
	    $CI= $stmt->rowCount();
	}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Edicion de Registros</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="style.css">

</head>
<body onload="habilitar()">
<h3 align="center" style="color: #0B3861">Edicion de Registro</h3>

<form method="POST" action="botones.php">

<div class="input-group">

<input type="hidden" name="orden" value="<?php echo("$orden");  ?>" required>
</div>

<div class="input-group">
<label>DNI:</label>
<input type="number" name="dni" value="<?php echo("$dni");?>" required>
</div>

<div class="input-group">
<label>Nombre y Apellido:</label>
<input type="text" name="nombreApellido" value="<?php echo("$nombreApellido");  ?>" required>
</div>

<div class="input-group">
<label>Escuela:</label>
<input type="text" name="escuela"  value="<?php echo("$escuela");?>" required>
</div>

<div class="input-group">
<label>Departamento:</label>
<input type="text" name="departamento" value="<?php echo("$departamento");  ?>" required>
</div>

<div class="input-group">
<label>Cargo:</label>
<input type="text" name="cargo"  value="<?php echo("$cargo");?>" required>
</div>

<div class="input-group">
<label>Jurado:</label>
<input type="number" name="jurado" min="1" max="10" value="<?php echo("$jurado");?>" >
</div>

<div class="input-group">
<label>Grupo:</label>
<input type="number" name="grupo" min="1" value="<?php echo("$grupo");?>" >
</div>

<div class="input-group">
<label>Oral ('T-P'):</label>
<input type="number" name="oralTP" min="0" max="10" value="<?php echo("$oralTP");?>"  id="valor1" onKeyUp="habilitar()" >
</div>

<div class="input-group">
<label>Apelacion Oral ('T-P'):</label>
<input type="number" name="apelOralTP" min="0" max="50" value="<?php echo("$apelOralTP");  ?>" id="valor2" onKeyUp="habilitar()">
</div>

<div class="input-group">
<label>Residencia:</label>
<input type="number" name="residencia" min="0" max="10" value="<?php echo("$residencia");?>" id="valor3" onKeyUp="habilitar()">
</div>

<div class="input-group">
<label>Apelacion (Residencia):</label>
<input type="number" name="apelRes" min="0" max="10" value="<?php echo("$apelRes");  ?>"  id="valor4" onKeyUp="habilitar()">
</div>


<div class="input-group">
<input type="submit" name="guardar" value="Guardar" class="btn" onclick="return confirm ('¿Desea guardar los cambios?')">
</div>


</form>

	<div class="input-group" align="center">
		<a href="./directivos.php">
		<input style="width: 100px" type="button" name="volver" value="Volver" class="btn" >
		</a>
	</div>


<script type="text/javascript">
		
	 function habilitar()

    {

        var camp1= document.getElementById('valor1');
        var camp2= document.getElementById('valor2');
        var camp3= document.getElementById('valor3');
        var camp4= document.getElementById('valor4');
       
     

        if (camp1.value == null || camp1.value == "") {

            camp2.disabled = false;
        }else {
            camp2.disabled = true;
        }

        if (camp2.value == null || camp2.value == "") {

            camp1.disabled = false;
        }else {
            camp1.disabled = true;
        }

         if (camp3.value == null || camp3.value == "") {

            camp4.disabled = false;
        }else {
            camp4.disabled = true;
        }

        if (camp4.value == null || camp4.value == "") {

            camp3.disabled = false;
        }else {
            camp3.disabled = true;
        }




    }

		

	</script>


</body>
</html>