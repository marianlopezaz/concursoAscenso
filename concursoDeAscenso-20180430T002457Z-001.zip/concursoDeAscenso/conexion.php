<?php
function conectar(){
$conn=null;
$host = "localhost";
$db= "planilla_concurso_de_ascenso";
$user="root";
$pass="";


try {

$conn= new PDO ('mysql:host='.$host.';dbname='.$db,$user,$pass);

} catch (PDOException $e) {
	echo ":(Error al conectar con la base de datos)". $e;
	exit;
	
}
return $conn;

}

?>