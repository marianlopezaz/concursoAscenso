<?php
function ShowTable (){							//ESTA FUNCION MUESTRA LOS RESULTADOS EN UNA TABLA									

	require("conexion.php");
	$con=conectar();
	$sql="SELECT * FROM directivos";
	$stmt= $con-> prepare($sql);
	$result = $stmt->execute();
	$rows= $stmt->fetchAll(\PDO::FETCH_OBJ);

		foreach ($rows as $row ) { 

									$orden=$row->orden;
									
								
					?>
						<tr>
											
											<td align="center">
												<?php 
												echo($row->orden); 
												?>
											</td>

											<td align="center">
												<?php 
												echo($row->dni); 
												?>
											</td>

											<td align="center">
												<?php 
												echo($row->nombreApellido); 
												?>
											</td>

											<td align="center">
												<?php 
												echo($row->escuela); 
												?>
											</td>

											<td align="center">
												<?php 
												echo($row->departamento); 
												?>
											</td>

											<td align="center">
												<?php 
												echo($row->cargo); 
												?>
											</td>

											<td align="center">
												<?php 
												echo($row->jurado); 
												?>
											</td>

											<td align="center">
												<?php 
												echo($row->grupo); 
												?>
											</td>

											<td align="center">
												<?php 
												echo($row->oralTP); 
												?>
											</td>

											<td align="center">
												<?php 
												echo($row->apelOralTP); 
												?>
											</td>

											
											<td align="center">
												<?php 
												echo($row->residencia); 
												?>
											</td>

											<td align="center">
												<?php 
												echo($row->apelRes); 
												?>
											</td>

											<td align="center">
												<?php 
												echo($row->puntDeOp); 
												?>
											</td>

											<td colspan="2" align="center">

											<a 
											href="editar.php?p=<?php echo $orden ?>&q=editar" class="edit_btn">Editar
											</a>

											<a
											 href="botones.php?p=<?php echo $orden ?>&q=eliminar" class="del_btn" 
											onclick="return confirm('¿Esta seguro que desea borrar el Registro?')">Eliminar
											</a>

											</td>

												
						</tr>

								<?php
								}

}
?>









<?php

function sessionMsg(){                         //ESTA FUNCION MUESTRA LOS DIFERENTES MENSAJES PARA AGREGAR/EDITAR Y ELIMINAR PRODUCTOS

						if (isset($_SESSION['msg'])) { //mensaje de agregado o editado
					?>

							<div class="msg">
								<?php 
									echo $_SESSION['msg'];
									unset($_SESSION['msg']);
								?>
							</div>
									
								
					<?php }
					if (isset($_SESSION['msg3'])&& isset($_SESSION['msg3'])) { 
					?>

							<div class="msg">
								<?php 
									echo $_SESSION['msg3'];
									unset($_SESSION['msg3']);
								?>
							</div>
									
								
					<?php }
						
						if (isset($_SESSION['msg1'])) {  //mensaje de eliminado
					?>

							<div class="msg1">
								<?php 
									echo $_SESSION['msg1'];
								  	unset($_SESSION['msg1']);
								?>
							</div>

					<?php }

					
					

		
}









function Botones(){                //ESTAS SON LAS FUNCIONES DE LOS DISTINTOS BOTONES DEL PROGRAMA

//FUNCIONES DE LOS BOTONES EDITAR Y ELIMINAR

if (isset($_GET['p']) && isset($_GET['q'])){

	$orden=$_GET['p'];
	
	if ($_GET['q']="eliminar") {
		session_start();
			
			$usuario = "root";
			$servidor = "localhost";
			$basededatos = "planilla_concurso_de_ascenso";
			$conexion = mysqli_connect("$servidor", "$usuario", "", "$basededatos");

			if (!$conexion) {
			    echo "Error: No se pudo conectar a MySQL." . PHP_EOL;
			    echo "errno de depuración: " . mysqli_connect_errno() . PHP_EOL;
			    echo "error de depuración: " . mysqli_connect_error() . PHP_EOL;
			    exit;
			}
		
			$db=mysqli_select_db($conexion,$basededatos);
			$db = mysqli_select_db( $conexion, $basededatos ) or die ( "Upps! no se ha podido conectar a la base de datos");

			$query="DELETE FROM `planilla_concurso_de_ascenso`.`directivos` WHERE `orden`='$orden';";
			$resultado = mysqli_query( $conexion, $query ) or die ( "Algo ha ido mal en la consulta a la base de datos");
			$_SESSION['msg1']="Se elmino el Registro correctamente";
				
				header("location: ./directivos.php");


exit();

}
	
}



$action="";

switch(isset($_POST))
{
	case isset($_POST['new']):
      $action=$_POST['new'];
    break;

    case isset($_POST['agregar']):
      $action=$_POST['agregar'];
    break;


    case isset($_POST['guardar']):
     $action=$_POST['guardar'];
     break;


}



switch ($action) {
							case 'new':
								
						 		header("location: ./agregar.php");

								break;

							case 'Agregar':

								//Vuelvo a conectar con la base de datos, es el mismo codigo que en conexion.php
									session_start();	
									$usuario = "root";
									$servidor = "localhost";
									$basededatos = "planilla_concurso_de_ascenso";
									$conexion = mysqli_connect("$servidor", "$usuario", "", "$basededatos");

									if (!$conexion) {
									    echo "Error: No se pudo conectar a MySQL." . PHP_EOL;
									    echo "errno de depuración: " . mysqli_connect_errno() . PHP_EOL;
									    echo "error de depuración: " . mysqli_connect_error() . PHP_EOL;
									    exit;
									}



										
									if (isset($_POST['dni']) && isset($_POST['nombreApellido']) &&
								        isset($_POST['escuela']) && isset($_POST['departamento'])&&
								        isset($_POST['cargo']) && 
								        isset($_POST['jurado']) && 
								        isset($_POST['grupo']) &&
								        isset($_POST['oralTP']) || isset($_POST['apelOralTP'])&&
								        isset($_POST['residencia']) ||
								        isset($_POST['apelRes']))
									{

										$dni=$_POST['dni'];	
										$nombreApellido= mb_strtoupper(($_POST['nombreApellido']));
										$escuela=mb_strtoupper($_POST['escuela']);
										$departamento=mb_strtoupper($_POST['departamento']);
										$cargo=mb_strtoupper($_POST['cargo']);
										$jurado=$_POST['jurado'];
										$grupo=$_POST['grupo'];
										$oralTP=$_POST['oralTP'];
										$apelOralTP=$_POST['apelOralTP'];
										$residencia=$_POST['residencia'];
										$apelRes=$_POST['apelRes'];
										$puntDeOp= $oralTP+$apelOralTP+$apelRes+$residencia;
												
										
									}

									$db = mysqli_select_db( $conexion, $basededatos ) or die ( "Upps! no se ha podido conectar a la base de datos");
									require("conexion.php");
									$con=conectar();
							try {

									$qp="SELECT grupo FROM directivos WHERE grupo ='$grupo'; ";
									
									$con=conectar();
									$stmt= $con-> prepare($qp);
								    $result = $stmt->execute();
								    $cuenta= $stmt->rowCount();
					
					if ($cuenta < 4) {

	
										$query="INSERT INTO directivos (
																			`dni`,
																			`nombreApellido`,
																			`escuela`,
																			`departamento`,
																			`cargo`,
																			`jurado`,
																			`grupo`,
																			`oralTP`,
																			`apelOralTP`,
																			`residencia`,
																			`apelRes`,
																			`puntDeOp`) 
																			VALUES (
																			'$dni',
																			'$nombreApellido',
																			'$escuela',
																			'$departamento',
																			'$cargo',
																			'$jurado',
																			'$grupo',
																			'$oralTP',
																			'$apelOralTP',
																			'$residencia',
																			'$apelRes',
																			'$puntDeOp');";

												

											}

									else { ?>
												

										<script language="JavaScript" type="text/javascript"> 
										    setTimeout( alert("Ya existen 4 grupos N° <?php echo $grupo ?>"),0); 
										    window.history.back();
										</script>
														
										<?php }

									$resultado = mysqli_query( $conexion, $query ) or die ( "Algo ha ido mal en la consulta a la base de datos");
									if ($resultado!=FALSE) {

										$_SESSION['msg']="Se agrego el Registro correctamente";
										# code...
									}
										
										
									} catch (Exception $e) {
												 echo 'Hubo un error al cargar el registro: ',  $e->getMessage();
															}	

								header("location: ./directivos.php");

								break;






									case 'Guardar':
								
								//Vuelvo a conectar con la base de datos, es el mismo codigo que en conexion.php
									session_start();

									$usuario = "root";
									$servidor = "localhost";
									$basededatos = "planilla_concurso_de_ascenso";
									$conexion = mysqli_connect("$servidor", "$usuario", "", "$basededatos");

									if (!$conexion) {
									    echo "Error: No se pudo conectar a MySQL." . PHP_EOL;
									    echo "errno de depuración: " . mysqli_connect_errno() . PHP_EOL;
									    echo "error de depuración: " . mysqli_connect_error() . PHP_EOL;
									    exit;
									}

						try {													
									if (isset($_POST['orden']) && 
										isset($_POST['dni']) && 
										isset($_POST['nombreApellido'])&&
								        isset($_POST['escuela']) &&
								        isset($_POST['departamento'])&&
								        isset($_POST['cargo']) &&
								        isset($_POST['jurado']) && 
								        isset($_POST['grupo']) &&
								        isset($_POST['oralTP']) ||
								        isset($_POST['apelOralTP'])&&
								        isset($_POST['residencia'])||
								        isset($_POST['apelRes'])) 
									{
										$orden=$_POST['orden'];
										$dni=$_POST['dni'];	
										$nombreApellido= mb_strtoupper(($_POST['nombreApellido']));
										$escuela=mb_strtoupper($_POST['escuela']);
										$departamento=mb_strtoupper($_POST['departamento']);
										$cargo=mb_strtoupper($_POST['cargo']);
										$jurado=($_POST['jurado']);
										$grupo=$_POST['grupo'];
										$oralTP=$_POST['oralTP'];
										$apelOralTP=$_POST['apelOralTP'];
										$residencia=$_POST['residencia'];
										$apelRes=$_POST['apelRes'];
										$puntDeOp= $oralTP+$apelOralTP+$apelRes+$residencia;

										

									}


										
													
									$db=mysqli_select_db($conexion,$basededatos);

									$db = mysqli_select_db( $conexion, $basededatos ) or die ( "Upps! no se ha podido conectar a la base de datos");
									require("conexion.php");

									$con=conectar();
									$qp2="SELECT grupo FROM directivos WHERE grupo='$grupo'; ";
								    		$stmt= $con-> prepare($qp2);
								    		$result = $stmt->execute();
								    		$cuenta= $stmt->rowCount();

							
					if ($cuenta < 4 || $grupo=="") {
								
									$query= 
									"UPDATE 
									`planilla_concurso_de_ascenso`.`directivos` 
									SET 
									`dni`='$dni',
									`nombreApellido`='$nombreApellido',
									`escuela`='$escuela',
									`departamento`='$departamento',
									`cargo`='$cargo',
									`jurado`='$jurado',
									`grupo`='$grupo',
									`oralTP`='$oralTP',
									`apelOralTP`='$apelOralTP',
									`residencia`='$residencia',
									`apelRes`='$apelRes',
									`puntDeOp`='$puntDeOp'

								WHERE orden='$orden';";

								$_SESSION['msg']="Cambios Guardados!";
						

							}else{ 

								$query= 
									"UPDATE 
									`planilla_concurso_de_ascenso`.`directivos` 
									SET 
									`dni`='$dni',
									`nombreApellido`='$nombreApellido',
									`escuela`='$escuela',
									`departamento`='$departamento',
									`cargo`='$cargo',
									`jurado`='$jurado',								  
									`oralTP`='$oralTP',
									`apelOralTP`='$apelOralTP',
									`residencia`='$residencia',
									`apelRes`='$apelRes',
									`puntDeOp`='$puntDeOp'

								WHERE orden='$orden';";

								$_SESSION['msg']="Cambios Guardados!";
								$_SESSION['msg3']="El campo 'Grupo' no ha sido editado puesto que se encontraba repetido, o no se ha cambiado";
								

								 }
												

								$resultado = mysqli_query( $conexion, $query ) or die ( "Algo ha ido mal en la consulta a la base de datos");

												} catch (Exception $e) {
												 echo 'Hubo un error al cargar el registro: ',  $e->getMessage();
					}	
								header("location: ./directivos.php");


								break;


								
								
									
						}
			}



?>








