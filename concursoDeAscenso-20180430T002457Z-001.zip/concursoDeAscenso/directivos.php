<?php
if (isset($_POST['export_data'])) {
	
header("Content-Type: application/vnd.ms-excel");

header("Expires: 0");

header("Cache-Control: must-revalidate, post-check=0, pre-check=0");

header("content-disposition: attachment;filename=directivos.xls");

}
require('functions.php');
session_start();
sessionMsg();


?>

<!DOCTYPE html>
<html>
<head>
	<title>Planilla</title>

	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta charset="utf-8">
	<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
	<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js">
		
	</script>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

	<h1 align="center">Concurso de Ascenso Directivos</h1>
<div align="right">	
	<table align="center">
	<form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="POST" >
	<tr><button class="btn" value="export_data" id="export_data" name="export_data" type="submit">Exportar a EXCEL</button></tr>
	</form>
	</div>
</table>
<table align="center">
<form method="POST" action="botones.php">

<tr>
	<td align="center"><button type="submit" name="new" value="new" class="btn">Nuevo Docente</button></td> 
	
</tr>

<div align="center">
		<a href="./index.php">
		<input style="width: 100px" type="button" name="inicio" value="Inicio" class="btn" >
		</a>
</div>


</form>
</table>

<table id="table" class="display" cellspacing="0" width="100%">
	<thead>
		<tr>
			<th>Orden</th>
			<th>DNI</th>
			<th>Nombre y Apellido</th>
			<th>Escuela</th>
			<th>Departamento</th>
			<th>Cargo</th>
			<th>Jurado</th>
			<th>Grupo</th>
			<th>Oral(TP)</th>
			<th>Apel. Oral (TP)</th>
			<th>Residencia</th>
			<th>Apel. Residencia</th>
			<th>Puntaje De Oposicion</th>
			<th>Accion</th>

			
		</tr>
	</thead>

	<tbody>
		<?php
		ShowTable();
		?>
	</tbody>

	<script type="text/javascript">
		$(document).ready(function() {
    $('#table').DataTable();
} );

	</script>

</body>
</html>