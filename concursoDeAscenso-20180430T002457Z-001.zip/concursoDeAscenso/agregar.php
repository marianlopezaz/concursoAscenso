<!DOCTYPE html>
<html>
<head>
	<title>Agregar Nuevo Docente</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<h3 align="center" style="color: #0B3861">Agrega un nuevo Docente</h3>

<form method="POST" action="botones.php">

<div class="input-group">
<label>DNI:</label>
<input type="number" maxlength="8" placeholder="XXXXXXXX" min="0" name="dni" required>
</div>

<div class="input-group">
<label>Nombre y Apellido:</label>
<input type="text"  name="nombreApellido" required>
</div>

<div class="input-group">
<label>Escuela:</label>
<input type="text" name="escuela"  required>
</div>

<div class="input-group">
<label>Departamento:</label>
<input type="text" name="departamento" required>
</div>

<div class="input-group">
<label>Cargo:</label>
<input type="text" name="cargo"  required>
</div>

<div class="input-group">
<label>Jurado:</label>
<input type="number" name="jurado" min="1" max="10">
</div>

<div class="input-group">
<label>Grupo:</label>
<input type="number" name="grupo" min="1">
</div>

<div class="input-group">
<label>Oral ('T-P'):</label>
<input type="number" name="oralTP" min="0" max="50" id="valor1" onKeyUp="habilitar()" >
</div>

<div class="input-group">
<label>Apelacion Oral ('T-P'):</label>
<input type="number" name="apelOralTP" min="0" max="50" id="valor2" onKeyUp="habilitar()" >
</div>

<div class="input-group">
<label>Residencia:</label>
<input type="number" name="residencia"  min="0" max="10" id="valor3" onKeyUp="habilitar()">
</div>

<div class="input-group">
<label>Apelacion (Residencia):</label>
<input type="number" name="apelRes"  min="0" max="10" id="valor4" onKeyUp="habilitar()" >
</div>



<div class="input-group">
<input type="submit" name="agregar" value="Agregar" class="btn" onclick="return confirm ('¿Seguro que desea Agregar el nuevo Registro?')">
</div>


</form>

	<div class="input-group" align="center">
		<a href="./directivos.php">
		<input style="width: 100px" type="button" name="volver" value="Volver" class="btn" >
		</a>
	</div>



<script type="text/javascript">
		
	 function habilitar()

    {

        var camp1= document.getElementById('valor1');
        var camp2= document.getElementById('valor2');
        var camp3= document.getElementById('valor3');
        var camp4= document.getElementById('valor4');
       
     

        if (camp1.value == null || camp1.value == "") {

            camp2.disabled = false;
        }else {
            camp2.disabled = true;
        }

        if (camp2.value == null || camp2.value == "") {

            camp1.disabled = false;
        }else {
            camp1.disabled = true;
        }

         if (camp3.value == null || camp3.value == "") {

            camp4.disabled = false;
        }else {
            camp4.disabled = true;
        }

        if (camp4.value == null || camp4.value == "") {

            camp3.disabled = false;
        }else {
            camp3.disabled = true;
        }




    }

		

	</script>

</body>
</html>
