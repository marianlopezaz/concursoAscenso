<?php
if (isset($_GET['p']) && isset($_GET['q'])){
	
	if ($_GET['q']="editar") {
		$orden=$_GET['p'];
}
		require("conexionSup.php");
		$con=conectar();
		$sql="SELECT orden,dni,nombreApellido,escuela,departamento,cargo,cargoQueAsp,sitAnt,jurado,grupo,oralTP,apelOralTP,apelRes,residencia FROM supervisores WHERE orden='$orden'";       
		$stmt= $con-> prepare($sql);
		$result = $stmt->execute();
		$rows= $stmt->fetchAll(\PDO::FETCH_OBJ);

		foreach ($rows as $row ) { 
			$orden=$row->orden;
			$dni=$row->dni;
			$nombreApellido=$row->nombreApellido;
			$escuela= $row->escuela;
			$departamento=$row->departamento;
			$cargo=$row->cargo;
			$cargoQueAsp=$row->cargoQueAsp;
			$sitAnt=$row->sitAnt;}
			$jurado=$row->jurado;
			$grupo=$row->grupo;
			$oralTP=$row->oralTP;
			$apelOralTP=$row->apelOralTP;
			$apelRes=$row->apelRes;
			$residencia=$row->residencia;

		$qp="SELECT grupo FROM supervisores WHERE grupo ='$grupo'; ";
		$stmt= $con-> prepare($qp);
	    $result = $stmt->execute();
	    $CI= $stmt->rowCount();
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Edicion de Registros</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="style.css">

</head>
<body onload="habilitar()">
<h3 align="center" style="color: #0B3861">Edicion de Registro</h3>

<form method="POST" action="botonesSup.php">

<div class="input-group">

<input type="hidden" name="orden" value="<?php echo("$orden");  ?>" required>
</div>

<div class="input-group">
<label>DNI:
<input type="number" name="dni" value="<?php echo("$dni");?>" required>
</label>
</div>

<div class="input-group">
<label>Nombre y Apellido:
<input type="text" name="nombreApellido" value="<?php echo("$nombreApellido");  ?>" required>
</label>
</div>

<div class="input-group">
<label>Escuela:
<input type="text" name="escuela"  value="<?php echo("$escuela");?>" required>
</label>
</div>

<div class="input-group">
<label>Departamento:
<input type="text" name="departamento" value="<?php echo("$departamento");  ?>" required>
</label>
</div>

<div class="input-group">
<label>Cargo:
<input type="text" name="cargo"  value="<?php echo("$cargo");?>" required>
</label>
</div>

<div class="input-group">
<label>Cargo Al Que Aspiran:
<input type="text" name="cargoQueAsp"  value="<?php echo("$cargoQueAsp");?>" required>
</label>
</div>

<div class="input-group">
<label>Situacion Anterior:
<select name="sitAnt" style="width: 96%; height: 50px">
	<option value="" <?php if ($sitAnt=='') { echo "selected";}?> ></option>
	<option value="SI" <?php if ($sitAnt=='SI') { echo "selected";}?> >SI</option>
	<option value="NO" <?php if ($sitAnt=='NO') { echo "selected";}?>>NO</option>
</select>
</label>
</div>

<div class="input-group">
<label>Jurado:
<input type="number" name="jurado" min="11" max="19" value="<?php echo("$jurado");?>">
</label>
</div>

<div class="input-group">
<label>Grupo:
<input type="number" name="grupo" min="1" value="<?php echo("$grupo");?>" >
</label>
</div>


<div class="input-group">
<label>Oral ('T-P'):
<input type="number" name="oralTP" id="oralTP" min="0" max="50" value="<?php echo("$oralTP");?>"  id="valor1" onKeyUp="habilitar()" >
</label>
</div>

<div class="input-group">
<label>Apelacion Oral ('T-P'):
<input type="number" name="apelOralTP" id="apelOralTP" min="0" max="50" value="<?php echo("$apelOralTP");  ?>"  id="valor1" onKeyUp="habilitar()" >
</label>
</div>

<div class="input-group">
<label>Residencia:
<input type="number" name="residencia" id="residencia" min="0" max="10" value="<?php echo("$residencia");?>"  id="valor1" onKeyUp="habilitar()" >
</label>
</div>

<div class="input-group">
<label>Apelacion (Residencia):
<input type="number" name="apelRes" id="apelRes" min="0" max="10" value="<?php echo("$apelRes");  ?>"  id="valor1" onKeyUp="habilitar()" >
</label>
</div>


<div class="input-group">
<input type="submit" name="guardar" value="Guardar" class="btn" onclick="return confirm ('¿Desea guardar los cambios?')">
</div>


</form>

	<div class="input-group" align="center">
		<a href="./supervision.php">
		<input style="width: 100px" type="button" name="volver" value="Volver" class="btn" >
		</a>
	</div>


<script type="text/javascript">
		
	 function habilitar()

    {

        var camp1= document.getElementById('valor1');
        var camp2= document.getElementById('valor2');
        var camp3= document.getElementById('valor3');
        var camp4= document.getElementById('valor4');
       
     

        if (camp1.value == null || camp1.value == "") {

            camp2.disabled = false;
        }else {
            camp2.disabled = true;
        }

        if (camp2.value == null || camp2.value == "") {

            camp1.disabled = false;
        }else {
            camp1.disabled = true;
        }

         if (camp3.value == null || camp3.value == "") {

            camp4.disabled = false;
        }else {
            camp4.disabled = true;
        }

        if (camp4.value == null || camp4.value == "") {

            camp3.disabled = false;
        }else {
            camp3.disabled = true;
        }




    }

		

	</script>

</body>
</html>