<!DOCTYPE html>
<html>
<head>
	<title>Agregar Nuevo Docente</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<h3 align="center" style="color: #0B3861">Agrega un nuevo Docente</h3>

<form method="POST" action="botonesSup.php">

<div class="input-group">
<label>DNI:
<input type="number" maxlength="8" placeholder="XXXXXXXX" min="0" name="dni" required>
</label>
</div>

<div class="input-group">
<label>Nombre y Apellido:
<input type="text"  name="nombreApellido" required>
</label>
</div>

<div class="input-group">
<label>Escuela:
<input type="text" name="escuela"  required>
</label>
</div>

<div class="input-group">
<label>Departamento:
<input type="text" name="departamento" required>
</label>
</div>

<div class="input-group">
<label>Cargo:
<input type="text" name="cargo"  required>
</label>
</div>

<div class="input-group">
<label>Cargo Al Que Aspiran:
<input type="text" name="cargoQueAsp"  required>
</label>
</div>

<div class="input-group">
<label>Situacion Anterior:
<select name="sitAnt" style="width: 96%; height: 50px">
    <option value="" selected></option>
	<option value="SI">SI</option>
	<option value="NO">NO</option>
</select>
</label>
</div>

<div class="input-group">
<label>Jurado:
<input type="number" name="jurado" min="11" max="19">
</label>
</div>

<div class="input-group">
<label>Grupo:
<input type="number" name="grupo" min="1">
</label>
</div>

<div class="input-group">
<label>Oral ('T-P'):
<input type="number" name="oralTP" min="0" max="50"  id="valor1" onKeyUp="habilitar()" >
</label>
</div>

<div class="input-group">
<label>Apelacion Oral ('T-P'):
<input type="number" name="apelOralTP" min="0" max="50"  id="valor2" onKeyUp="habilitar()" >
</label>
</div>

<div class="input-group">
<label>Residencia:
<input type="number" name="residencia"  min="0" max="10"  id="valor3" onKeyUp="habilitar()" >
</label>
</div>

<div class="input-group">
<label>Apelacion (Residencia):
<input type="number" name="apelRes"  min="0" max="10"  id="valor4" onKeyUp="habilitar()" >
</label>
</div>



<div class="input-group">
<input type="submit" name="agregar" value="Agregar" class="btn" onclick="return confirm ('¿Seguro que desea Agregar el nuevo Registro?')">
</div>


</form>

	<div class="input-group" align="center">
		<a href="./supervision.php">
		<input style="width: 100px" type="button" name="volver" value="Volver" class="btn" >
		</a>
	</div>


<script type="text/javascript">
		
	 function habilitar()

    {

        var camp1= document.getElementById('valor1');
        var camp2= document.getElementById('valor2');
        var camp3= document.getElementById('valor3');
        var camp4= document.getElementById('valor4');
       
     

        if (camp1.value == null || camp1.value == "") {

            camp2.disabled = false;
        }else {
            camp2.disabled = true;
        }

        if (camp2.value == null || camp2.value == "") {

            camp1.disabled = false;
        }else {
            camp1.disabled = true;
        }

         if (camp3.value == null || camp3.value == "") {

            camp4.disabled = false;
        }else {
            camp4.disabled = true;
        }

        if (camp4.value == null || camp4.value == "") {

            camp3.disabled = false;
        }else {
            camp3.disabled = true;
        }




    }

		

	</script>

</body>
</html>
