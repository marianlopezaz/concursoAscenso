<!DOCTYPE html>
<html>
<head>
	<title>Inicio</title>
</head>
<body>
	<title>INICIO</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="style.css">
<h1 align="center">CONCURSO DE ASCENSO</h1>
<table align="center">
	<th><a href="directivos.php"><button class="btn">DIRECTIVOS</button></a></th>
	<th><a href="supervision/supervision.php"><button class="btn">SUPERVISORES</button></a></th>

</table>

</body>
</html>